import React from 'react';

const Home = () => (
    <div className="title">
        <h4>Home</h4>
        <p>Essa é minha página inicial.</p>
    </div>
);

export default Home;